#Examples

A directory for example Common Workflow Language apps (tools and workflows) which can be run using bunny (rabix local executor).
