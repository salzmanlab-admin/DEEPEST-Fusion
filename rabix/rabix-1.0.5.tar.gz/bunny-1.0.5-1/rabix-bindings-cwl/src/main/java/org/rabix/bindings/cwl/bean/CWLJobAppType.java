package org.rabix.bindings.cwl.bean;

public enum CWLJobAppType {

  WORKFLOW,
  COMMAND_LINE_TOOL,
  EXPRESSION_TOOL,
  PYTHON_TOOL,
  EMBEDDED

}
