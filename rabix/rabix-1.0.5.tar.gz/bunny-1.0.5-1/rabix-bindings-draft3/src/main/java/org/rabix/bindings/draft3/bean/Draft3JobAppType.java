package org.rabix.bindings.draft3.bean;

public enum Draft3JobAppType {

  WORKFLOW,
  COMMAND_LINE_TOOL,
  EXPRESSION_TOOL,
  PYTHON_TOOL,
  EMBEDDED

}
