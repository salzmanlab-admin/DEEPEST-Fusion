package org.rabix.bindings.draft3.conformance;

import org.testng.annotations.Test;

@Test(groups = { "functional" })
public class ConformanceExecutionTest {

}
