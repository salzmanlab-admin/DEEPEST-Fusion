package org.rabix.backend.tes.model;

public enum TESFileType {
  FILE,
  DIRECTORY
}
