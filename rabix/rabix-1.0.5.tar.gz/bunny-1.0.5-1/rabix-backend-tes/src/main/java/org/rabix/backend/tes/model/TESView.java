package org.rabix.backend.tes.model;

public enum TESView {
    MINIMAL,
    BASIC,
    FULL
}
