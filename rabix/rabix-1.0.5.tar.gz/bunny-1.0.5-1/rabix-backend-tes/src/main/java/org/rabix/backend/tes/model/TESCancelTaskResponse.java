package org.rabix.backend.tes.model;

public class TESCancelTaskResponse {
}
