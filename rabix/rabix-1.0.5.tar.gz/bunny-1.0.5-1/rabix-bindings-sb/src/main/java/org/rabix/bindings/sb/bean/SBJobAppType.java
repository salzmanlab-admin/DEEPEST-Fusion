package org.rabix.bindings.sb.bean;

public enum SBJobAppType {

  WORKFLOW,
  COMMAND_LINE_TOOL,
  EXPRESSION_TOOL,
  PYTHON_TOOL,
  EMBEDDED

}
